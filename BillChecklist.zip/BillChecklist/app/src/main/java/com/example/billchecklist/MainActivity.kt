package com.example.billchecklist

import android.Manifest
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.billchecklist.data.AppDatabase
import com.example.billchecklist.data.Bill
import com.example.billchecklist.data.BillMonthlyRecord
import com.example.billchecklist.data.BillStatus
import com.example.billchecklist.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: AppDatabase
    private lateinit var adapter: BillAdapter

    private val currentMonthYear: String
        get() = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

    private val todayStr: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        db = AppDatabase.getDatabase(this)

        val displayMonth = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
        supportActionBar?.subtitle = displayMonth

        createNotificationChannel()
        requestNotificationPermission()
        setupRecyclerView()

        lifecycleScope.launch { initCurrentMonth() }

        observeCurrentMonthRecords()
        observePendingCount()

        binding.fabAddBill.setOnClickListener { showAddBillDialog() }
    }

    // ── Month Initialisation ──────────────────────────────────────────────────

    private suspend fun initCurrentMonth() {
        val count = db.billMonthlyRecordDao().getCountForMonth(currentMonthYear)
        if (count == 0) {
            val activeBills = db.billDao().getActiveBillsOnce()
            if (activeBills.isNotEmpty()) {
                val records = activeBills.map { bill ->
                    BillMonthlyRecord(
                        billId    = bill.id,
                        billName  = bill.name,
                        monthYear = currentMonthYear,
                        status    = initialStatusFor(bill)
                    )
                }
                db.billMonthlyRecordDao().insertRecords(records)
            }
        }
    }

    /** Bills inside their skip-date window start as NOT_REQUIRED (yellow). */
    private fun initialStatusFor(bill: Bill): BillStatus {
        val start = bill.skipStartDate ?: return BillStatus.PENDING
        val end   = bill.skipEndDate   ?: return BillStatus.PENDING
        return if (todayStr in start..end) BillStatus.NOT_REQUIRED else BillStatus.PENDING
    }

    // ── RecyclerView ──────────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = BillAdapter(
            onStatusCycle = { record, newStatus ->
                lifecycleScope.launch {
                    db.billMonthlyRecordDao().updateStatus(record.id, newStatus)
                }
            },
            onDeleteClick = { record -> confirmDeleteBill(record) }
        )
        binding.recyclerViewBills.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewBills.adapter = adapter
    }

    private fun observeCurrentMonthRecords() {
        lifecycleScope.launch {
            db.billMonthlyRecordDao()
                .getRecordsForMonth(currentMonthYear)
                .collectLatest { records ->
                    adapter.submitList(records)

                    val paid        = records.count { it.status == BillStatus.PAID }
                    val notRequired = records.count { it.status == BillStatus.NOT_REQUIRED }
                    val pending     = records.count { it.status == BillStatus.PENDING }
                    val total       = records.size

                    binding.tvSummary.text = when {
                        total == 0 -> "No bills yet — tap + to add one"
                        else       -> "✓ Paid: $paid   — Skipped: $notRequired   ● Pending: $pending"
                    }

                    binding.progressBills.max      = total.coerceAtLeast(1)
                    binding.progressBills.progress = paid + notRequired
                }
        }
    }

    // ── Red icon badge via notification ───────────────────────────────────────

    private fun observePendingCount() {
        lifecycleScope.launch {
            db.billMonthlyRecordDao()
                .getPendingCountForMonth(currentMonthYear)
                .collectLatest { pendingCount ->
                    updateAppBadge(pendingCount)
                }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Unpaid Bills",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows a badge when you have unpaid bills"
            setShowBadge(true)
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    /**
     * Posts a silent notification whose [number] drives the launcher badge count.
     * If 0 pending — badge is cleared entirely.
     */
    private fun updateAppBadge(pendingCount: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (pendingCount == 0) {
            nm.cancel(NOTIF_ID)
            return
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_badge_red)
            .setContentTitle("$pendingCount unpaid bill${if (pendingCount == 1) "" else "s"}")
            .setContentText("Open Bill Checklist to review")
            .setNumber(pendingCount)
            .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
            .setSilent(true)
            .build()
        nm.notify(NOTIF_ID, notification)
    }

    // ── Add Bill Dialog ───────────────────────────────────────────────────────

    private fun showAddBillDialog() {
        var chosenStart: String? = null
        var chosenEnd:   String? = null
        val sdfDisplay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val sdfKey     = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }

        val etName = EditText(this).apply { hint = "e.g. Electricity, Rent, Netflix…" }
        container.addView(etName)

        val tvSkipLabel = TextView(this).apply {
            text = "⚠  Skip dates (optional — bill turns yellow)"
            textSize = 13f
            setPadding(0, 24, 0, 4)
            setTextColor(getColor(R.color.not_required_yellow))
        }
        container.addView(tvSkipLabel)

        val tvFrom = TextView(this).apply {
            text = "📅  From: not set"
            textSize = 14f
            setPadding(0, 8, 0, 4)
        }
        container.addView(tvFrom)
        tvFrom.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val date = Calendar.getInstance().also { it.set(y, m, d) }.time
                chosenStart = sdfKey.format(date)
                tvFrom.text = "📅  From: ${sdfDisplay.format(date)}"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                .show()
        }

        val tvTo = TextView(this).apply {
            text = "📅  To: not set"
            textSize = 14f
            setPadding(0, 4, 0, 8)
        }
        container.addView(tvTo)
        tvTo.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val date = Calendar.getInstance().also { it.set(y, m, d) }.time
                chosenEnd = sdfKey.format(date)
                tvTo.text = "📅  To: ${sdfDisplay.format(date)}"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                .show()
        }

        val tvClear = TextView(this).apply {
            text = "✕  Clear skip dates"
            textSize = 13f
            setTextColor(getColor(R.color.pending_red))
            setPadding(0, 0, 0, 4)
        }
        container.addView(tvClear)
        tvClear.setOnClickListener {
            chosenStart = null; chosenEnd = null
            tvFrom.text = "📅  From: not set"
            tvTo.text   = "📅  To: not set"
        }

        AlertDialog.Builder(this)
            .setTitle("Add New Bill")
            .setView(container)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString().trim()
                when {
                    name.isEmpty() ->
                        Toast.makeText(this, "Please enter a bill name", Toast.LENGTH_SHORT).show()
                    (chosenStart == null) != (chosenEnd == null) ->
                        Toast.makeText(this,
                            "Set both From and To dates, or neither", Toast.LENGTH_SHORT).show()
                    else -> addBill(name, chosenStart, chosenEnd)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addBill(name: String, skipStart: String?, skipEnd: String?) {
        lifecycleScope.launch {
            val billId = db.billDao().insertBill(
                Bill(name = name, skipStartDate = skipStart, skipEndDate = skipEnd)
            ).toInt()

            val status = if (skipStart != null && skipEnd != null && todayStr in skipStart..skipEnd)
                BillStatus.NOT_REQUIRED else BillStatus.PENDING

            db.billMonthlyRecordDao().insertRecord(
                BillMonthlyRecord(
                    billId    = billId,
                    billName  = name,
                    monthYear = currentMonthYear,
                    status    = status
                )
            )

            val msg = if (skipStart != null)
                "\"$name\" added — auto-yellow from $skipStart to $skipEnd"
            else "\"$name\" added!"
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    // ── Delete Bill ───────────────────────────────────────────────────────────

    private fun confirmDeleteBill(record: BillMonthlyRecord) {
        AlertDialog.Builder(this)
            .setTitle("Remove \"${record.billName}\"?")
            .setMessage("Removes from future months. History stays saved.")
            .setPositiveButton("Remove") { _, _ ->
                lifecycleScope.launch {
                    db.billDao().softDeleteBill(record.billId)
                    db.billMonthlyRecordDao()
                        .deleteRecordForMonth(currentMonthYear, record.billId)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Menu ──────────────────────────────────────────────────────────────────

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.action_history -> {
            startActivity(Intent(this, HistoryActivity::class.java))
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    companion object {
        private const val CHANNEL_ID = "bill_checklist_channel"
        private const val NOTIF_ID   = 1001
    }
}
