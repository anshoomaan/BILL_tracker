package com.example.billchecklist.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Bill::class, BillMonthlyRecord::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun billDao(): BillDao
    abstract fun billMonthlyRecordDao(): BillMonthlyRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * v1 → v2:
         *  • bills: add skipStartDate, skipEndDate columns
         *  • bill_monthly_records: add status column (replaces isPaid logic)
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Add skip-date columns to bills
                database.execSQL(
                    "ALTER TABLE bills ADD COLUMN skipStartDate TEXT"
                )
                database.execSQL(
                    "ALTER TABLE bills ADD COLUMN skipEndDate TEXT"
                )
                // Add status column; map old isPaid boolean → status string
                database.execSQL(
                    "ALTER TABLE bill_monthly_records ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'"
                )
                // Migrate existing paid=1 rows to PAID
                database.execSQL(
                    "UPDATE bill_monthly_records SET status = 'PAID' WHERE isPaid = 1"
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bill_checklist_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
