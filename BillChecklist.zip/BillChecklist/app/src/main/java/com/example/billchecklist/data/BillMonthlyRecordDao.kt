package com.example.billchecklist.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BillMonthlyRecordDao {

    @Query("SELECT * FROM bill_monthly_records WHERE monthYear = :monthYear ORDER BY billName ASC")
    fun getRecordsForMonth(monthYear: String): Flow<List<BillMonthlyRecord>>

    @Query("SELECT * FROM bill_monthly_records WHERE monthYear = :monthYear ORDER BY billName ASC")
    suspend fun getRecordsForMonthOnce(monthYear: String): List<BillMonthlyRecord>

    @Query("""
        SELECT DISTINCT monthYear FROM bill_monthly_records
        WHERE monthYear != :currentMonth
        ORDER BY monthYear DESC
    """)
    fun getPastMonths(currentMonth: String): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM bill_monthly_records WHERE monthYear = :monthYear")
    suspend fun getCountForMonth(monthYear: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: BillMonthlyRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecords(records: List<BillMonthlyRecord>)

    @Query("UPDATE bill_monthly_records SET status = :status WHERE id = :recordId")
    suspend fun updateStatus(recordId: Int, status: BillStatus)

    @Query("DELETE FROM bill_monthly_records WHERE monthYear = :monthYear AND billId = :billId")
    suspend fun deleteRecordForMonth(monthYear: String, billId: Int)

    /** Count only PENDING bills for the current month — used for the red icon badge */
    @Query("SELECT COUNT(*) FROM bill_monthly_records WHERE monthYear = :monthYear AND status = 'PENDING'")
    fun getPendingCountForMonth(monthYear: String): Flow<Int>
}
