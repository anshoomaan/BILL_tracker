package com.example.billchecklist.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a recurring bill tracked every month.
 *
 * [skipStartDate] / [skipEndDate] are "yyyy-MM-dd" strings.
 * When today falls within this range the bill is automatically
 * marked NOT_REQUIRED (yellow) — meaning it doesn't need to be paid.
 */
@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val isActive: Boolean = true,
    /** Inclusive start of the "not required" date window, e.g. "2026-06-01" */
    val skipStartDate: String? = null,
    /** Inclusive end of the "not required" date window, e.g. "2026-08-31" */
    val skipEndDate: String? = null
)
