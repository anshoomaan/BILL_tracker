package com.example.billchecklist

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.billchecklist.data.BillMonthlyRecord
import com.example.billchecklist.data.BillStatus

class BillAdapter(
    private val onStatusCycle: (BillMonthlyRecord, BillStatus) -> Unit,
    private val onDeleteClick: (BillMonthlyRecord) -> Unit
) : ListAdapter<BillMonthlyRecord, BillAdapter.BillViewHolder>(DiffCallback()) {

    inner class BillViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvBillName:     TextView    = view.findViewById(R.id.tvBillName)
        val tvStatus:       TextView    = view.findViewById(R.id.tvStatus)
        val tvSkipDates:    TextView    = view.findViewById(R.id.tvSkipDates)
        val btnStatusToggle: TextView   = view.findViewById(R.id.btnStatusToggle)
        val btnDelete:      ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BillViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bill, parent, false)
        return BillViewHolder(view)
    }

    override fun onBindViewHolder(holder: BillViewHolder, position: Int) {
        val record = getItem(position)
        val ctx    = holder.itemView.context

        holder.tvBillName.text = record.billName

        // Hide skip-dates label (set from outside via tag if needed)
        val skipLabel = holder.itemView.getTag(R.id.tvSkipDates) as? String
        if (skipLabel != null) {
            holder.tvSkipDates.visibility = View.VISIBLE
            holder.tvSkipDates.text = skipLabel
        } else {
            holder.tvSkipDates.visibility = View.GONE
        }

        when (record.status) {
            BillStatus.PAID -> {
                holder.tvBillName.paintFlags =
                    holder.tvBillName.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                holder.tvStatus.text = "✓ Paid"
                holder.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.paid_green))
                holder.btnStatusToggle.text = "✓"
                holder.btnStatusToggle.backgroundTintList =
                    ContextCompat.getColorStateList(ctx, R.color.paid_green)
                holder.itemView.alpha = 0.80f
            }
            BillStatus.NOT_REQUIRED -> {
                holder.tvBillName.paintFlags =
                    holder.tvBillName.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                holder.tvStatus.text = "— Not Required"
                holder.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.not_required_yellow))
                holder.btnStatusToggle.text = "—"
                holder.btnStatusToggle.backgroundTintList =
                    ContextCompat.getColorStateList(ctx, R.color.not_required_yellow)
                holder.itemView.alpha = 0.85f
            }
            BillStatus.PENDING -> {
                holder.tvBillName.paintFlags =
                    holder.tvBillName.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                holder.tvStatus.text = "● Pending"
                holder.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.pending_red))
                holder.btnStatusToggle.text = "●"
                holder.btnStatusToggle.backgroundTintList =
                    ContextCompat.getColorStateList(ctx, R.color.pending_red)
                holder.itemView.alpha = 1.0f
            }
        }

        // Tapping the toggle button cycles: PENDING → PAID → NOT_REQUIRED → PENDING
        holder.btnStatusToggle.setOnClickListener {
            val next = when (record.status) {
                BillStatus.PENDING      -> BillStatus.PAID
                BillStatus.PAID         -> BillStatus.NOT_REQUIRED
                BillStatus.NOT_REQUIRED -> BillStatus.PENDING
            }
            onStatusCycle(record, next)
        }

        holder.btnDelete.setOnClickListener { onDeleteClick(record) }
    }

    class DiffCallback : DiffUtil.ItemCallback<BillMonthlyRecord>() {
        override fun areItemsTheSame(old: BillMonthlyRecord, new: BillMonthlyRecord) =
            old.id == new.id
        override fun areContentsTheSame(old: BillMonthlyRecord, new: BillMonthlyRecord) =
            old == new
    }
}
