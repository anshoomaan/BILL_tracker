package com.example.billchecklist.data

enum class BillStatus {
    PENDING,       // Red  – bill needs to be paid
    PAID,          // Green – bill has been paid
    NOT_REQUIRED   // Yellow – bill is skipped / not applicable this period
}
