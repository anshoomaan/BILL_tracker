package com.example.billchecklist.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromBillStatus(status: BillStatus): String = status.name

    @TypeConverter
    fun toBillStatus(value: String): BillStatus =
        BillStatus.valueOf(value)
}
