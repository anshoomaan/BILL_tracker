package com.example.billchecklist

import com.example.billchecklist.data.BillMonthlyRecord

sealed class HistoryItem {

    data class MonthHeader(
        val monthDisplay: String,
        val monthYear: String,
        val paidCount: Int,
        val skippedCount: Int,
        val pendingCount: Int,
        val totalCount: Int
    ) : HistoryItem()

    data class BillRecord(
        val record: BillMonthlyRecord
    ) : HistoryItem()
}
