package com.example.billchecklist.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One record per bill per month.
 * [status] is one of PENDING / PAID / NOT_REQUIRED.
 * monthYear format: "yyyy-MM"  e.g. "2026-03"
 */
@Entity(tableName = "bill_monthly_records")
data class BillMonthlyRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val billId: Int,
    val billName: String,
    val monthYear: String,
    val status: BillStatus = BillStatus.PENDING
)
